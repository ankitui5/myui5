sap.ui.define([
	"com/safran/ewm/zewm_dispatch/test/unit/controller/View1.controller"
], function () {
	"use strict";
});