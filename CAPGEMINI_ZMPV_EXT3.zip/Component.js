/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("sed.mpe.prodver.manages1.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");
sap.ui.generic.app.AppComponent.extend("sed.mpe.prodver.manages1.Component",{
	metadata:{"manifest":"json"}
});
