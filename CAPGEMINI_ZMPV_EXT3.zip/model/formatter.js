/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	] , function () {
		"use strict";

		return {

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnitFormat : function(sValue){
				if(sValue){
					var sTrimmedValue = sValue.replace(/^0+/, "");
					return sTrimmedValue;
				}else{
						return sValue;
				}
			},
			/**
			 * Get the date in (mon DD,YYYY) format.
			 * @public
			 * @param {string} sValue the date string.
			 * @returns {string} sValue with date format
			 */
			formatValidityDate : function(sDateVal){
				if(sDateVal)
				{
					if(sDateVal.getFullYear() < 9999){
						var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							    pattern: "dd/MM/yyyy"
						});
						return	oDateFormat.format(sDateVal);
					}else{
						return this.getView().getModel("i18n").getResourceBundle().getText("unlimited");
					}
				}else{
					return sDateVal;
				}
			},
			/**
			 * Get the Minimum Lot Size value.
			 * @public
			 * @param {string} sValue the string.
			 * @returns {string} sValue number and unit.
			 */
			getMinimumLotSize : function(sValue){
				if(sValue){
					if (sValue.indexOf("-") !== -1){
						var aResultArray = sValue.split("-");
						return aResultArray[0];
					}else{
						return sValue;
					}
				}else{
					return sValue;
				}
			},
			/**
			 * Get the Maximum Lot Size value.
			 * @public
			 * @param {string} sValue the string.
			 * @returns {string} sValue number and unit.
			 */
			getMaximumLotSize : function(sValue){
				if(sValue){
					 if (sValue.indexOf("-") !== -1){
						var aResultArray = sValue.split("-");
						return aResultArray[1];
					 }else {
						return sValue;
					 }
				}else{
					return sValue;
				}
			}
			

		};

	}
);