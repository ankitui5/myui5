/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/comp/smartfilterbar/SmartFilterBar",
	"sap/m/MessageBox",
	"sap/i2d/mpe/lib/popovers1/fragments/MaterialController",
	"sed/mpe/prodver/manages1/model/formatter"
], function (Filter, SmartFilterBar, MessageBox, MaterialPopOver, formatter) {
	"use strict";

	/*
	 * @Description (ListReportExtension.controller.js)
	 * @class This Js file is used to extend the controller to give customization.
	 * @name sed.mpe.prodver.manages1.ext.controller.ListReportExtension
	 * @public
	 */
	sap.ui.controller("sed.mpe.prodver.manages1.ext.controller.ListReportExtension", {

		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * @public
		 */
		onInit: function () {
			this.oMaterialPopOver = new MaterialPopOver();
			this.getView().byId(
				"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--addEntry").setVisible(
				false);
			this.getView().byId(
				"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--listReport").setUseExportToExcel(
				true);
			this.getView().byId(
				"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--listReport").attachBeforeExport(
				this.onBeforeExport, this);
			this.getView().byId("sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--page")
				.setPreserveHeaderStateOnScroll(
					true);
			this._oPrdVersionTable = null;
			/*	var serviceUrl = "/sap/opu/odata/sap/ZPP_ADDING_FIE_MPV_SRV/";
				var oDataModel = new sap.ui.model.odata.ODataModel(serviceUrl, true);*/
			this.oDataModel = this.getOwnerComponent().getModel("Custom_Model");
			sap.ui.getCore().setModel(this.oDataModel, "MainModel");
			var oData = {
				Material: "",
				Plant: "",
				Version: "",
				Amend: "",
				Ebom: "",
				Devno: "",
				Aqua: "",
				Alert: "",
				Matu: "",
				Doknr: "",
				Dokar: "",
				Doktl: "",
				Dokvr: "",
				Dktxt: "",
				Zzprevpv: "",
				Zzplanning: "",
				Aenst: "", //shalini
				LinkToCM: "", //shalini
				Disabled: "",
				Mksp: "",
				bEditMode:false,
			};

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(oData);
			sap.ui.getCore().setModel(oModel, "ObjectPageModel");
			var oEntry = {
				Matu: [{
					"Key": "",
					"MAT": ""

				}, {
					"Key": "I0",
					"MAT": "I0"

				}, {
					"Key": "I1",
					"MAT": "I1"
				}, {
					"Key": "I2",
					"MAT": "I2"
				}, {
					"Key": "I3",
					"MAT": "I3"
				}, {
					"Key": "I4",
					"MAT": "I4"
				}, {
					"Key": "INDÉTERMINÉ",
					"MAT": "INDÉTERMINÉ"
				}]

			};
			var oModelMatu = new sap.ui.model.json.JSONModel({
				aEntry: oEntry
			});
			sap.ui.getCore().setModel(oModelMatu, "MATUMODEL");
			var oAlert = {
				Alert: [{
					"Key": "",
					"ALERT": ""

				}, {
					"Key": "OUI",
					"ALERT": "OUI"

				}, {
					"Key": "NON",
					"ALERT": "NON"
				}]

			};
			var oModelAlert = new sap.ui.model.json.JSONModel({
				aAlert: oAlert
			});
			sap.ui.getCore().setModel(oModelAlert, "ALERTMODEL");
			var oMultiInputModel = new sap.ui.model.json.JSONModel({
				aMultiInput: []
			});
			sap.ui.getCore().setModel(oMultiInputModel, "MULTIINPUTMODEL");
			this._oCopyEvntHndlr = sap.ui.getCore().byId(
				"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--action::MPE_MANAGE_PRODVER_SRV.MPE_MANAGE_PRODVER_SRV_Entities::C_ProdnVersObjPgTPCopy"
			);
			sap.ui.getCore().byId(
				"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--action::MPE_MANAGE_PRODVER_SRV.MPE_MANAGE_PRODVER_SRV_Entities::C_ProdnVersObjPgTPCopy"
			).setEnabled(false);
			this._oCopyEvntHndlr.attachPress(this.onCopyPress, this);

		},
		onBeforeExport: function (oEvent) {
			var oSource = oEvent.getSource();
			for (var i = 0; i <= oEvent.getParameters().exportSettings.workbook.columns.length - 1; i++) {
				if (oEvent.getParameters().exportSettings.workbook.columns[i].property[0] === 'ProductionVersionForEdit') {
					oEvent.getParameters().exportSettings.workbook.columns[i].property = ['ProductionVersionForEdit'];
					oEvent.getParameters().exportSettings.workbook.columns[i].template = "{0}";
				}
			}
		},
		onCopyPress: function () {
			this._oPrdVersionTable = this.getView().byId(
				"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_ProdnVersObjPgTP--listReport");
			var oTable = this._oPrdVersionTable.getTable();
			var oObject = oTable.getSelectedContexts()[0].getObject();
			var aData = [];
			aData.push({
				Material: oObject.Material !== "" ? oObject.Material : oObject.MaterialForEdit
			}, {
				Plant: oObject.Plant !== "" ? oObject.Plant : oObject.PlantForEdit
			}, {
				Version: oObject.ProductionVersion
			}, {
				bEditable: "true"
			});
			var oEntry = {
				Matu: [{
					"Key": "",
					"MAT": ""
				}, {
					"Key": "I0",
					"MAT": "I0"
				}, {
					"Key": "I1",
					"MAT": "I1"
				}, {
					"Key": "I2",
					"MAT": "I2"
				}, {
					"Key": "I3",
					"MAT": "I3"
				}, {
					"Key": "I4",
					"MAT": "I4"
				}, {
					"Key": "INDÉTERMINÉ",
					"MAT": "INDÉTERMINÉ"
				}]
			};
			var oModelMatu = new sap.ui.model.json.JSONModel({
				aEntry: oEntry
			});
			sap.ui.getCore().setModel(oModelMatu, "MATUMODEL");
			var oAlert = {
				Alert: [{
					"Key": "",
					"ALERT": ""

				}, {
					"Key": "OUI",
					"ALERT": "OUI"

				}, {
					"Key": "NON",
					"ALERT": "NON"
				}]

			};
			var oModelAlert = new sap.ui.model.json.JSONModel({
				aAlert: oAlert
			});
			sap.ui.getCore().setModel(oModelAlert, "ALERTMODEL");
			var oTokenModel = sap.ui.getCore().getModel("MULTIINPUTMODEL");
			oTokenModel.setData({
				aMultiInput: []
			});
			//var oDataModel = sap.ui.getCore().getModel("MainModel");

			this.oDataModel.read("/ZPP_HEADERSet(Material='" + aData[0].Material + "',Plant='" + aData[1].Plant + "',Version='" + aData[2].Version +
				"')",

				{
					success: function (oData) {
						var oModel = new sap.ui.model.json.JSONModel();
						sap.ui.getCore().setModel(oModel, "ObjectPageModel");
						oModel.setData(oData);
						oModel.setProperty("/bEditable", true);
						oModel.updateBindings(true);
						var sNumDevs = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Devno");
						if (sNumDevs !== "") {
							var aNumDevs = sNumDevs.split(",");
							var aTokens = [];
							for (var i = 0; i < aNumDevs.length; i++) {
								aTokens[i] = {
									key: i,
									text: aNumDevs[i]
								};
							}
							oTokenModel.setData({
								aMultiInput: aTokens
							});
							sap.ui.getCore().setModel(oTokenModel);
						}
					},
					error: function () {
						sap.m.MessageToast.show("Got Empty response");
					}

				});

			// this.oDataModel.read("/ZPP_DOCRECORDSet(Material='" + aData[0].Material + "',Plant='" + aData[1].Plant + "',Version='" + aData[2].Version +	"')",
			// {
			// 	success: function (oData) {

			// 		var oModel = new sap.ui.model.json.JSONModel();
			// 		oModel = sap.ui.getCore().getModel("ObjectPageModel");
			// 		oModel.setProperty("/Doknr", oData.Doknr);
			// 		oModel.setProperty("/Dokar", oData.Dokar);
			// 		oModel.setProperty("/Doktl", oData.Doktl);
			// 		oModel.setProperty("/Dokvr", oData.Dokvr);
			// 		oModel.setProperty("/Dktxt", oData.Dktxt);
			// 		sap.ui.getCore().setModel(oModel, "ObjectPageModel");
			// 		oModel.updateBindings(true);
			// 	},
			// 	error: function () {
			// 		sap.m.MessageToast.show("Got Empty response");
			// 	}

			// });

			// this.oDataModel.read("/ZPP_PLANDATASet(Material='" + aData[0].Material + "',Plant='" + aData[1].Plant + "',Version='" + aData[2].Version +	"')",
			// {
			// 	success: function (oData) {

			// 		var oModel = new sap.ui.model.json.JSONModel();
			// 		oModel = sap.ui.getCore().getModel("ObjectPageModel");
			// 		oModel.setProperty("/Zzprevpv", oData.Zzprevpv);
			// 		oModel.setProperty("/Zzplanning", oData.Zzplanning);
			// 		sap.ui.getCore().setModel(oModel, "ObjectPageModel");
			// 		oModel.updateBindings(true);
			// 	},
			// 	error: function () {
			// 		sap.m.MessageToast.show("Got Empty response");
			// 	}

			// });

		},

		onInitSmartFilterBarExtension: function (oEvent) {
			// Store the reference of smart filterbar so that this can be used later to access the individual filter controls.
			this._oWorkList = null;
		},
		onCallActionFromToolBar: function (oEvent) {
			var oSource = oEvent.getSource();
		},
		/**
		 * handler function fires when smart table header go button clicked .
		 * 
		 * @param {sap.ui.base.Event} oEvent Event object
		 * @private
		 * @memberOf sed.mpe.prodver.manages1.ext.controller.ListReportExtension
		 */
		onBeforeRebindTableExtension: function (oEvent) {
			// This condition is used to make sure that selectionChange and dataReceived events
			// are attached to the table only onc
			if (!this._oPrdVersionTable) {
				this._oPrdVersionTable = this.getView().byId(oEvent.getSource().getId());

				// COPY Button enablement Handling:
				// Enable or dsiable the copy button based on the Table Selection
				var oTable = this._oPrdVersionTable.getTable();
				oTable.attachSelectionChange(this._enableOrDisableCopyButton, this);

				// When you try to create new production version and press discard, copy button enablement is not consistent.
				this._oPrdVersionTable.attachDataReceived(this._enableOrDisableCopyButton, this);
			}

			// Holds all the custom filters.
			var aCustomFilter = [];
			//Get the selected filter values for Plant and Production Plant filters.
			var oKeyDataFilterValue = this.getView().byId("keyDateFilter").getValue();
			if (oKeyDataFilterValue) {
				oKeyDataFilterValue = new Date(oKeyDataFilterValue);
				var oNewDateTime = oKeyDataFilterValue.valueOf() - oKeyDataFilterValue.getTimezoneOffset() * 60 * 1000;
				oKeyDataFilterValue = new Date(oNewDateTime);
			}

			if (oKeyDataFilterValue) {
				aCustomFilter.push(new sap.ui.model.Filter("ValidityStartDate", sap.ui.model.FilterOperator.LE, oKeyDataFilterValue));
				aCustomFilter.push(new sap.ui.model.Filter("ValidityEndDate", sap.ui.model.FilterOperator.GE, oKeyDataFilterValue));
			}
			// Add all the custom filters to table filter.
			var aTableFilters = oEvent.getParameter("bindingParams").filters;
			this._applyCustomFilter(aCustomFilter, aTableFilters);
		},
		onListNavigationExtension: function (oEventOrSource, oState, onListNavigationExtension, oBindingContext, bIsProgrammatic) {
			// method is called in different ways:
			// - UI table: source of event is context to navigate to
			// - responsive Table: itemPress event of table must be used, context to navigate to is provided in paramter listItem
			// - programmatical navigation: no event, but an item (ColumnListItem?) is provided
			// - chart: navigation target provided in oBindingContext, Extension not provided???
			// event source contains also information in custom data, if navigation is overidden by external navigation
			var oEventSource;
			if (oEventOrSource) {
				oEventSource = oEventOrSource.getSource();
				if (oEventSource) {
					var oObject = oEventSource.getBindingContext().getObject();
					var aData = [];
					aData.push({
						Material: oObject.Material !== "" ? oObject.Material : oObject.MaterialForEdit

					}, {
						Plant: oObject.Plant !== "" ? oObject.Plant : oObject.PlantForEdit
					}, {
						Version: oObject.ProductionVersion

					}, {
						bEditable: "true"
					});
				}
			} else {
				// programmatical case
				oEventSource = oEventOrSource;
			}

			var oEntry = {
				Matu: [{
					"Key": "",
					"MAT": ""

				}, {
					"Key": "I0",
					"MAT": "I0"

				}, {
					"Key": "I1",
					"MAT": "I1"
				}, {
					"Key": "I2",
					"MAT": "I2"
				}, {
					"Key": "I3",
					"MAT": "I3"
				}, {
					"Key": "I4",
					"MAT": "I4"
				}, {
					"Key": "INDÉTERMINÉ",
					"MAT": "INDÉTERMINÉ"
				}]

			};
			var oModelMatu = new sap.ui.model.json.JSONModel({
				aEntry: oEntry
			});
			sap.ui.getCore().setModel(oModelMatu, "MATUMODEL");
			var oAlert = {
				Alert: [{
					"Key": "",
					"ALERT": ""

				}, {
					"Key": "OUI",
					"ALERT": "OUI"

				}, {
					"Key": "NON",
					"ALERT": "NON"
				}]

			};
			var oModelAlert = new sap.ui.model.json.JSONModel({
				aAlert: oAlert
			});
			sap.ui.getCore().setModel(oModelAlert, "ALERTMODEL");
			var oTokenModel = sap.ui.getCore().getModel("MULTIINPUTMODEL");
			oTokenModel.setData({
				aMultiInput: []
			});
			//var oDataModel = sap.ui.getCore().getModel("MainModel");
			var sVersionFromModel;
			this.oDataModel.read("/ZPP_HEADERSet(Material='" + aData[0].Material + "',Plant='" + aData[1].Plant + "',Version='" + aData[2].Version +
				"')",

				{
					success: function (oData, oResponse) {
						if (!sap.ui.getCore().getModel("ObjectPageModel")) {
							var oModel = new sap.ui.model.json.JSONModel();
							sap.ui.getCore().setModel(oModel, "ObjectPageModel");
							oModel.setData(oData);
							sVersionFromModel = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Version");
							if (sVersionFromModel === "") {
								oModel.setProperty("/bEditable", true);
							}
							oModel.setProperty("/bEditable", false);
							sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bCreateFlag", false);
							oModel.updateBindings(true);
						} else {
							sap.ui.getCore().getModel("ObjectPageModel").setData(oData);
							sVersionFromModel = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Version");
							if (sVersionFromModel === "") {
								sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", true);
							} else {
								sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
							}
							sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bCreateFlag", false);
							sap.ui.getCore().getModel("ObjectPageModel").updateBindings(true);
						}
						var sNumDevs = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Devno");
						if (sNumDevs !== "") {
							var aNumDevs = sNumDevs.split(",");
							var aTokens = [];
							for (var i = 0; i < aNumDevs.length; i++) {
								aTokens[i] = {
									key: i,
									text: aNumDevs[i]
								};
							}
							oTokenModel.setData({
								aMultiInput: aTokens
							});
							sap.ui.getCore().setModel(oTokenModel);
						}
					},
					error: function (oError) {
						sap.m.MessageToast.show("Got Empty response");
					}

				});

			// this.oDataModel.read("/ZPP_DOCRECORDSet(Material='" + aData[0].Material + "',Plant='" + aData[1].Plant + "',Version='" + aData[2].Version +	"')",
			// {
			// 	success: function (oData) {

			// 		var oModel = new sap.ui.model.json.JSONModel();
			// 		oModel = sap.ui.getCore().getModel("ObjectPageModel");
			// 		oModel.setProperty("/Doknr", oData.Doknr);
			// 		oModel.setProperty("/Dokar", oData.Dokar);
			// 		oModel.setProperty("/Doktl", oData.Doktl);
			// 		oModel.setProperty("/Dokvr", oData.Dokvr);
			// 		oModel.setProperty("/Dktxt", oData.Dktxt);
			// 		sap.ui.getCore().setModel(oModel, "ObjectPageModel");
			// 		oModel.updateBindings(true);
			// 	},
			// 	error: function () {
			// 		sap.m.MessageToast.show("Got Empty response");
			// 	}

			// });

			// this.oDataModel.read("/ZPP_PLANDATASet(Material='" + aData[0].Material + "',Plant='" + aData[1].Plant + "',Version='" + aData[2].Version +	"')",
			// {
			// 	success: function (oData) {

			// 		var oModel = new sap.ui.model.json.JSONModel();
			// 		oModel = sap.ui.getCore().getModel("ObjectPageModel");
			// 		oModel.setProperty("/Zzprevpv", oData.Zzprevpv);
			// 		oModel.setProperty("/Zzplanning", oData.Zzplanning);
			// 		sap.ui.getCore().setModel(oModel, "ObjectPageModel");
			// 		oModel.updateBindings(true);
			// 	},
			// 	error: function () {
			// 		sap.m.MessageToast.show("Got Empty response");
			// 	}

			// });
		},
		/**
		 * Helper function to enable or disable the copy button based on the table selection.
		 * 
		 * @param {sap.ui.base.Event} oEvent Event object
		 * @public
		 * @memberOf sed.mpe.prodver.manages1.ext.ext.controller.ListReportExtension
		 */
		_enableOrDisableCopyButton: function (oEvent) {
			var sCopyBtnID = this.createId("action::MPE_MANAGE_PRODVER_SRV.MPE_MANAGE_PRODVER_SRV_Entities::C_ProdnVersObjPgTPCopy");
			var oView = this.getView();
			var oTable = oEvent.getSource().getTable ? oEvent.getSource().getTable() : oEvent.getSource();
			if (oTable instanceof sap.m.Table) {
				var aSelectedItems = oTable.getSelectedItems();
				if (aSelectedItems && aSelectedItems.length === 1) {
					oView.byId(sCopyBtnID).setEnabled(true);
				} else {
					oView.byId(sCopyBtnID).setEnabled(false);
				}
			}
		},

		/**
		 * handler function for press event on material object, Plant Object and MRP Controller Object to show the details on a Popover.
		 * 
		 * @param {sap.ui.base.Event} oEvent Event object
		 * @public
		 * @memberOf sed.mpe.prodver.manages1.ext.ext.controller.ListReportExtension
		 */
		handleMaterialPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			var oModel = oContext.getModel();
			var sProductionPlant = oModel.getProperty("PlantForEdit", oContext);
			var sMaterial = this.formatter.numberUnitFormat(oModel.getProperty("MaterialForEdit", oContext));
			// var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			// var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
			// 	target: {
			// 		semanticObject: "Material",
			// 		action: "display"
			// 	},
			// 	params: {
			// 		"Material": oEvent.getSource().getBindingContext().getObject().Material
			// 	}
			// })) || ""; // generate the Hash to display a Supplier
			// oCrossAppNavigator.toExternal({
			// 	target: {
			// 		shellHash: hash
			// 	}
			// });
			this.oMaterialPopOver.openMaterialPopOver(oEvent, this, sMaterial, sProductionPlant);
		},

		/**
		 * Helper function to add custom filter to existing smart table filters
		 * @public
		 * @param {Array} aCustomFilters array of Filter object
		 * @param {Array} aTableFilters Filter array
		 * @memberOf sed.mpe.prodver.manages1.ext.controller.ListReportExtension
		 **/
		_applyCustomFilter: function (aCustomFilters, aTableFilters) {
			$.each(aCustomFilters, function (iIndex, oCustomFilter) {
				if (aTableFilters.length !== 0) {
					if (aTableFilters[0].bAnd) {
						aTableFilters[0].aFilters.push(oCustomFilter);
					} else {
						aTableFilters[0] = new sap.ui.model.Filter([aTableFilters[0], oCustomFilter], true);
					}

					aTableFilters[0].bAnd = true;
				} else {
					aTableFilters.push(oCustomFilter);
				}
			});
		},

		onClickActionHistory: function (oEvent) {
			alert("alert2");
		},

		// Added functionality for Add button on table header.
		onClickActionCProdnVersObjPgTP1: function (oEvent) {
				//this.bCreateFlag=true;
				var oData = {
					Material: "",
					Plant: "",
					Version: "",
					Amend: "",
					Ebom: "",
					Devno: "",
					Aqua: "",
					Alert: "",
					Matu: "",
					Doknr: "",
					Dokar: "",
					Doktl: "",
					Dokvr: "",
					Dktxt: "",
					Zzprevpv: "",
					Zzplanning: "",
					bEditable: true,
					Aenst: "", //shalini
					LinkToCM: "", //shalini
					Disabled: "",
					Mksp: "",
					bEditMode:false,

				};
				sap.ui.getCore().getModel("ObjectPageModel").setData(oData);
				sap.ui.getCore().getModel("MULTIINPUTMODEL").setData({
					aMultiInput: []
				});
				sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bCreateFlag", true);
				var that = this;
				var entityPath = "/C_ProdnVersObjPgTP";
				this.getOwnerComponent().getModel().createEntry(entityPath, {
					success: $.proxy(function (Data1) {
						var entityPath1 = "/C_ProdnVersObjPgTP(Material='',Plant='',ProductionVersion='',DraftUUID=guid'" + Data1.DraftUUID +
							"',IsActiveEntity=false)";
						//var entityPath2 = "/C_ProdnVersObjPgTP(Material='',Plant='',ProductionVersion='',DraftUUID=guid'8cdcd400-8ed0-1ee7-8d90-7084eaca2df8',IsActiveEntity=false)";
						this.getOwnerComponent().getModel().read(entityPath1, {
							success: $.proxy(function (Data) {
								that.getView().getController().getOwnerComponent().getRouter().navTo("C_ProdnVersObjPgTP", {
									keys1: "Material='" + Data.Material + "',Plant='" + Data.Plant + "',ProductionVersion='" + Data.ProductionVersion +
										"',DraftUUID=guid'" + Data.DraftUUID + "',IsActiveEntity=" + Data.IsActiveEntity
								}, false);
							}, this)
						});
					}, this),
					error: jQuery.proxy(function (oError) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						that.getView().setBusy(false);
						sap.m.MessageBox.error(
							JSON.parse(oError.responseText).error.message.value, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}, this)
				});

			}
			/**
			 * Hook to update custom filters to app state
			 * @param {Object} oCustomData containing custom filters to be updated to app state
			 * @public
			 * @memberOf sed.mpe.prodver.manages1.ext.controller.ListReportExtension
			 **/
			/*getCustomAppStateDataExtension: function (oCustomData) {
				oCustomData.keyDate = this.byId("keyDateFilter").getDateValue();
			},*/
			/**
			 * Hook to retrieve custom filters from app state
			 * @param {Object} oCustomData containing custom filters to be restored from app state
			 * @public
			 * @memberOf sed.mpe.prodver.manages1.ext.controller.ListReportExtension
			 **/
			/*restoreCustomAppStateDataExtension: function (oCustomData) {
				if (oCustomData) {
					var oKeyDateFilter = this.byId("keyDateFilter");
					if (oKeyDateFilter) {
						oKeyDateFilter.setDateValue(oCustomData.keyDate ? new Date(oCustomData.keyDate) : null);
					}
				}
			}*/

	});
});