/*sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/Token"
], function() {
	"use strict";*/

sap.ui.controller("sed.mpe.prodver.manages1.ext.controller.ObjectPageExtension", {

	// Refactored by FT059443A
	_aGroupElements: [
		"Production1::IssuingStorageLocation",
		"Production1::ProductionLine",
		"Production1::MainProduct",
		"Production2::ReceivingStorageLocation",
		"Production2::ProductionVersionGroup",
		"Production3::DistributionKey",
		"Production3::ProductionSupplyArea",
		"Production2::OriginalBatchReferenceMaterial",
		"Production3::MaterialCostApportionmentStruc",
		"SelectionCriteria2::ProdnVersIsAllowedForRptvMfg"
	],

	onInit: function () {
		// Refactored by FT059443A - START
		var oView = this.getView();
		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
		var aGroupElements = this._aGroupElements;
		aGroupElements.forEach(function (sElementId) {
			var oGroupElement = sap.ui.getCore().byId(sViewId + "--com.sap.vocabularies.UI.v1.FieldGroup::" + sElementId + "::GroupElement");
			if (oGroupElement) {
				oGroupElement.setVisible(false);
			}
		});

		this.objModel = sap.ui.getCore().getModel("ObjectPageModel");

		var oModel = sap.ui.getCore().getModel("ObjectPageModel");
		oView.setModel(oModel, "ObjectPageModel");
		sap.ui.getCore().setModel(oModel, "ObjectPageModel");

		//added by : Shalini  Rana(FT059491A)- E197 part3
		var oViewModel = new sap.ui.model.json.JSONModel();
		oView.setModel(oViewModel, "viewModel");
		oView.getModel("viewModel").setData({
			isDisabled: true,
			// bSaved: false,
			isEditable: false
		})

		this.objModel.setProperty("/bSaved", false) //added by : Shalini  Rana(FT059491A)- E197 part3
		this.objModel.setProperty("/bEdit", false) //added by : Shalini  Rana(FT059491A)- E197 part3

		// this.objModel.setProperty("/isEditable", false) //added by : Shalini  Rana(FT059491A)- E197 part3

		var oModelMatu = sap.ui.getCore().getModel("MATUMODEL");
		oView.setModel(oModelMatu, "MATUMODEL");

		var oModelAlert = sap.ui.getCore().getModel("ALERTMODEL");
		oView.setModel(oModelAlert, "ALERTMODEL");

		var oMultiInputModel = sap.ui.getCore().getModel("MULTIINPUTMODEL");
		oView.setModel(oMultiInputModel, "MULTIINPUTMODEL");

		sap.ui.getCore().setModel(oMultiInputModel, "MULTIINPUTMODEL");
		var oMultiInput = oView.byId("idMultiInput");
		if (oMultiInput) {
			oMultiInput.addValidator(function (args) {
				var text = args.text;
				return new sap.m.Token({
					key: text,
					text: text
				});
			});
		}

		this._oCopyEvntHndlr = sap.ui.getCore().byId(sViewId +
			"--action::MPE_MANAGE_PRODVER_SRV.MPE_MANAGE_PRODVER_SRV_Entities::C_ProdnVersObjPgTPCopy");
		this._oCopyEvntHndlr.attachPress(this.onCopyPress, this);

		var that = this;
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.getRoute("C_ProdnVersObjPgTP").attachMatched(that._onRouteMatched, that);
		that._onRouteMatched();
		this._oEditButton = sap.ui.getCore().byId(sViewId + "--edit");
		if (this._oEditButton) {
			this._oEditButton.attachPress(this.onEditPress, this);
			// this._oEditButton.attachEventOnce("press", this.onEditPress, this);

		}

		// FT059443A - No longer needed - Using standadard binding to enable custom fields
		// this._oCancelButton = sap.ui.getCore().byId(sViewId + "--discard");
		// if (this._oCancelButton) {
		// 	this._oCancelButton.attachPress(this.onCancelPress, this);
		// }

		// FT059491A-- shalini
		this._oLockStatus = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-comboBoxEdit")
		if (this._oLockStatus) {}
		// var lock = sap.ui.getCore().byId(sViewId +
		// "--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-comboBoxEdit").getSelectedItem();

		this._oSaveButton = sap.ui.getCore().byId(sViewId + "--activate");
		if (this._oSaveButton) {
			// Override standard save button press event
			this._oSaveButtonPressEvent = this._oSaveButton.mEventRegistry.press[0].fFunction;
			this._oSaveButton.mEventRegistry.press[0].fFunction = function () {
				// Run custom logic to check mandatory fields

				this.NewStartDate = sap.ui.getCore().byId(sViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ValidityStartDate::Field-datePicker").getValue().split(".");
				this.NewStartDate = this.NewStartDate[2] + this.NewStartDate[1] + this.NewStartDate[0];
				this.NewEndDate = sap.ui.getCore().byId(sViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ValidityEndDate::Field-datePicker").getValue().split(".");
				this.NewEndDate = this.NewEndDate[2] + this.NewEndDate[1] + this.NewEndDate[0];
				this.NewLockStatus = sap.ui.getCore().byId(sViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-comboBoxEdit").getSelectedKey();
				const objModel = this.getView().getModel("ObjectPageModel");

				// Changes done by:Shalini Rana(FT059491A)- E197 part3
				const {
					LinkToCM,
					Disabled,
					Mksp,
					bCreateFlag
				} = objModel.oData;
				if (bCreateFlag || (LinkToCM === "N" && (Disabled === "N" && Mksp !== ""))) {
					if (this._checkMandatoryFields()) {
						this._oSaveButtonPressEvent.apply(this, arguments); // Execute standard save function
						setTimeout(function () {
							this.onSaveCustom(); // Execute custom save function
						}.bind(this), 4000);
					}
				} else {
					//change master is Yes
					this._oSaveButtonPressEvent.apply(this, arguments); // Execute standard save function
					setTimeout(function () {
						this.onSaveCustom(); // Execute custom save function
					}.bind(this), 4000);
				}

				// if (this._checkMandatoryFields()) {
				// 	//only needs to be called when change master is NO and for Yes only savecustom needs to be called -- shalini
				// 	this._oSaveButtonPressEvent.apply(this, arguments); // Execute standard save function

				// 	// FT059491A- shalini
				// 	setTimeout(function () {
				// 		this.onSaveCustom(); // Execute custom save function
				// 	}.bind(this), 4000);
				// }
			}.bind(this);
		}
		// if (this._oSaveButton) {
		// 	this._oSaveButton.attachPress(this.onSaveCustom, this);
		// }

		this._oFetchVersionButton = sap.ui.getCore().byId(sViewId + "--action::ActionC_ProdnVersObjPgTP1buttonUpdate");
		if (this._oFetchVersionButton) {
			this._oFetchVersionButton.attachPress(this.onFetchPress, this);
		}

		const oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		var impactPlanningData = {
			"selectedimpactplanning": oBundle.getText("lbl_no"),
			"impactplanning": [{
				"key": "",
				"Name": ""
			}, {
				"key": "1",
				"Name": oBundle.getText("lbl_yes")
			}, {
				"key": "2",
				"Name": oBundle.getText("lbl_no")
			}, {
				"key": "3",
				"Name": "N/A"
			}],
		};
		var impactPlannimgModel = new sap.ui.model.json.JSONModel();

		impactPlannimgModel.setData(impactPlanningData);
		this.getView().setModel(impactPlannimgModel, "impactPlannimgModel");

	},
	onAfterRendering: function () {
		//CHnages done by FT059491A- Shalini Rana
		this._aObjectIdsToHide = [
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::MaterialMinLotSizeQuantity::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::MaterialMaxLotSizeQuantity::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ChangeNumber::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::Production1::BillOfMaterialVariant::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::Production2::BillOfMaterialVariantUsage::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::Production1::BillOfOperationsType::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::Production2::BillOfOperationsGroup::Field",
			"--com.sap.vocabularies.UI.v1.FieldGroup::Production3::BillOfOperationsVariant::Field",
			"AmendementID",
			"EbomID",
			"idProdVerBfrEvolution",
			"idDocDesigntion",
			// "idAqua",
			// "AlertComboBoxId",
			"idImpactPlanning",
			"idMultiInput"
		]
		this._aObjectIdsToHide.forEach(function (sId) {
			var updatedId;
			if (sId.includes("--")) {
				updatedId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP" + sId;
			} else {
				updatedId = sId;
			}
			var oControl = this.getView().byId(updatedId);
			if (oControl) {
				oControl.bindProperty("enabled", "viewModel>/isDisabled");

			}
		}.bind(this))

	},

	setFieldMode: function (bEnabled) {
		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
		const {
			bCreateFlag,
			Aenst,
			LinkToCM,
			Mksp,
			Disabled
		} = this.getView().getModel("ObjectPageModel").oData;

		var isEnabled = true;
		if (!bCreateFlag) {
			if (LinkToCM === "N") {
				if (Disabled === "Y" || Mksp === "") {
					//not locked situation
					isEnabled = false
				} else if (Disabled === "N" && Mksp !== "") {
					//did not find unlocked status in history table
					isEnabled = true;
				}

			} else {
				//linked to CM --- Y
				if (Aenst === "03" && LinkToCM === "Y") {
					isEnabled = false;
				}

			}

		} else {
			isEnabled = true
		}
		this.getView().getModel("viewModel").setProperty("/isDisabled", isEnabled)

	},
	onLockChange: function (oEvent) {
		//FT059491A - Shalini  Rana
		// const bEdit = this.getView().getModel("viewModel").getProperty("/isEditable")
		// const bEdit = this.objModel.getProperty("/bEdit")
		const bCreate = this.objModel.getProperty("/bCreateFlag")

		let isEnabled = true;
		if (bCreate) {
			return
		}
		const selectedKey = oEvent.getParameter("value")
		const sLinkToCM = this.objModel.oData.LinkToCM;
		const sAenst = this.objModel.oData.Aenst;
		const Disabled = this.objModel.oData.Disabled;
		const Mksp = this.objModel.oData.Mksp;

		// if (sLinkToCM === "N" && (Disabled === "Y" || Mksp === "")) {
		if (sLinkToCM === "N" && (Disabled === "Y" || selectedKey === "")) {

			isEnabled = false //unlocked condition

		} else if (sLinkToCM === "Y" && sAenst === "03") {

			isEnabled = false //unlocked condition

		} else {
			//disabled is N
			isEnabled = true //not unlocked condition
		}
		// if (!selectedKey && sLinkToCM === "N") {
		// 	isEnabled = false //disable all fields
		// } else if (sLinkToCM === "Y" && sAenst === "03") {
		// 	isEnabled = false //disable all fields

		// } else {
		// 	//anything else -- enable the fields
		// 	isEnabled = true
		// }
		this.getView().getModel("viewModel").setProperty("/isDisabled", isEnabled)

	},
	_checkMandatoryFields: function () {
		// TODO: Logic to check if mandatory fields are filled
		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
		var lock = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-comboBoxEdit").getSelectedItem();
		var lockstatus;
		if (lock == null) {
			lockstatus = sap.ui.getCore().byId(sViewId +
				"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-comboBoxEdit").getSelectedKey();
		} else {
			lockstatus = lock.getKey();
		}
		var docmandatorycheck = false;
		var plantmandatorycheck = true;
		var oView = this.getView();
		var docNo = this.getView().getModel("ObjectPageModel").oData.Doknr;
		if (docNo == undefined)
			docNo = "";
		var docType = this.getView().getModel("ObjectPageModel").oData.Dokar;
		if (docType == undefined)
			docType = "";
		var docPart = this.getView().getModel("ObjectPageModel").oData.Doktl;
		if (docPart == undefined)
			docPart = "";
		var docVersion = this.getView().getModel("ObjectPageModel").oData.Dokvr;
		if (docVersion == undefined)
			docVersion = "";
		var docDesigntion = this.getView().getModel("ObjectPageModel").oData.Dktxt;
		if (docDesigntion == undefined)
			docDesigntion = "";

		var prodbeforevolution = this.getView().getModel("ObjectPageModel").oData.Zzprevpv;
		if (prodbeforevolution == undefined)
			prodbeforevolution = "";
		var impactPlanning = this.getView().getModel("ObjectPageModel").oData.Zzplanning;
		if (impactPlanning == undefined)
			impactPlanning = "";

		if ((docNo != "" && docType != "" && docPart != "" && docVersion != "" && docDesigntion != "") || (docNo == "" && docType == "" &&
				docPart == "" && docVersion == "" && docDesigntion == ""))
			docmandatorycheck = true;
		else {
			if (docNo == "" || docNo == undefined) {
				sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel").oData.idDocNo).setValueState(sap.ui.core.ValueState.Error);
			}
			if (docType == "" || docType == undefined) {
				sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel").oData.idDocType).setValueState(sap.ui.core.ValueState.Error);
			}
			if (docPart == "" || docPart == undefined) {
				sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel").oData.idDocPart).setValueState(sap.ui.core.ValueState.Error);
			}
			if (docVersion == "" || docVersion == undefined) {
				sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel").oData.idDocVersion).setValueState(sap.ui.core.ValueState.Error);
			}
			if (docDesigntion == "" || docDesigntion == undefined) {
				sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel").oData.idDocDesigntion).setValueState(sap.ui.core.ValueState.Error);
			}

			sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("dvValidation"));

		}
		if (lockstatus == "") {
			if (prodbeforevolution == "" || impactPlanning == "") {
				if (prodbeforevolution == "") {
					sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel1").oData.idProdVerBfrEvolution).setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("plngValidation", [
						this.getView().getModel("i18n").getResourceBundle().getText("ProdVerBfrEvolution"), this.oVersion, this.oMaterial
					]));
				}
				if (impactPlanning == "") {
					sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel1").oData.idImpactPlanning).setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("plngValidation", [
						this.getView().getModel("i18n").getResourceBundle().getText("ImpactPlanning"), this.oVersion, this.oMaterial
					]));
				}

				plantmandatorycheck = false;
			}
		}
		if (docmandatorycheck && plantmandatorycheck)
			return true;
		else
			return false;
		// Return true if YES, return false is NO
	},

	_onRouteMatched: function () {
		if (this.getView().getId().toString().includes("__xmlview")) {
			var setModel = false;
			var setModel1 = false;

			if (this.getView().byId("idDocNo") != undefined) {
				this.idDocNo = this.getView().byId("idDocNo").getId();
				setModel = true;
				this.f4oDataCalls("/ZSDOKNRVH_C");
				this.f4oDataCalls("/ZSDOKARVH_C");
				this.f4oDataCalls("/ZSDOKTLVH_C");
				this.f4oDataCalls("/ZSDOKVRVH_C");
			}
			if (this.getView().byId("idDocType") != undefined)
				this.idDocType = this.getView().byId("idDocType").getId();
			if (this.getView().byId("idDocPart") != undefined)
				this.idDocPart = this.getView().byId("idDocPart").getId();
			if (this.getView().byId("idDocVersion") != undefined)
				this.idDocVersion = this.getView().byId("idDocVersion").getId();
			if (this.getView().byId("idDocDesigntion") != undefined)
				this.idDocDesigntion = this.getView().byId("idDocDesigntion").getId();
			if (this.getView().byId("idProdVerBfrEvolution") != undefined) {
				this.idProdVerBfrEvolution = this.getView().byId("idProdVerBfrEvolution").getId();
				setModel1 = true;
				this.f4oDataCalls("/ZPP_PLANDATASet");
			}
			if (this.getView().byId("idImpactPlanning") != undefined)
				this.idImpactPlanning = this.getView().byId("idImpactPlanning").getId();

			if (setModel == true) {
				var idModelData = {
					idDocNo: this.getView().byId("idDocNo").getId().toString(),
					idDocType: this.getView().byId("idDocType").getId().toString(),
					idDocPart: this.getView().byId("idDocPart").getId().toString(),
					idDocVersion: this.getView().byId("idDocVersion").getId().toString(),
					idDocDesigntion: this.getView().byId("idDocDesigntion").getId().toString()
				};
				var idModel = new sap.ui.model.json.JSONModel();
				idModel.setData(idModelData);
				sap.ui.getCore().setModel(idModel, "idModel");
			}
			if (setModel1 == true) {
				var idModelData = {
					idProdVerBfrEvolution: this.getView().byId("idProdVerBfrEvolution").getId().toString(),
					idImpactPlanning: this.getView().byId("idImpactPlanning").getId().toString()
				};
				var idModel = new sap.ui.model.json.JSONModel();
				idModel.setData(idModelData);
				sap.ui.getCore().setModel(idModel, "idModel1");
			}
		}

		var oObjectPageModel = sap.ui.getCore().getModel("ObjectPageModel");
		if (oObjectPageModel) {
			this.getView().setModel(oObjectPageModel, "ObjectPageModel");
			var sAmend = oObjectPageModel.getProperty("/Amend");
			var sEbom = oObjectPageModel.getProperty("/Ebom");
			var sAlert = oObjectPageModel.getProperty("/Alert");
			var sAqua = oObjectPageModel.getProperty("/Aqua");
			var sDevno = oObjectPageModel.getProperty("/Devno");
			var sMatu = oObjectPageModel.getProperty("/Matu");

			var sDoknr = oObjectPageModel.getProperty("/Doknr");
			var sDokar = oObjectPageModel.getProperty("/Dokar");
			var sDoktl = oObjectPageModel.getProperty("/Doktl");
			var sDokvr = oObjectPageModel.getProperty("/Dokvr");
			var sDktxt = oObjectPageModel.getProperty("/Dktxt");
			var sZzprevpv = oObjectPageModel.getProperty("/Zzprevpv");
			var sZzplanning = oObjectPageModel.getProperty("/Zzplanning");
			var isCreate = oObjectPageModel.getProperty("/bCreateFlag");
			const oViewModel = this.getView().getModel("viewModel");
			this.objModel.setProperty("/bSaved", false) //added by : Shalini  Rana(FT059491A)- E197 part3
				// oViewModel.setProperty("/isEditable", false) //added by : Shalini  Rana(FT059491A)- E197 part3
			this.objModel.setProperty("/bEdit", false) //added by : Shalini  Rana(FT059491A)- E197 part3
				//check to make fields as enabled always in create mode // FT059491A - Shalini Rana

			if (isCreate) {
				this.getView().getModel("viewModel").setProperty("/isDisabled", true)
			}
			if (sZzplanning !== undefined && sZzplanning === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Zzplanning", "");
			if (sZzprevpv !== undefined && sZzprevpv === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Zzprevpv", "");
			if (sDoknr !== undefined && sDoknr === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Doknr", "");
			if (sDokar !== undefined && sDokar === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Dokar", "");
			if (sDoktl !== undefined && sDoktl === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Doktl", "");
			if (sDokvr !== undefined && sDokvr === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Dokvr", "");
			if (sDktxt !== undefined && sDktxt === "")
				this.getView().getModel("ObjectPageModel").setProperty("/Dktxt", "");

			if ((sAmend !== undefined && sAmend === "") && (sEbom !== undefined && sEbom === "") && (sDevno !== undefined && sDevno === "") &&
				(sAlert !== undefined && sAlert === "") && (sAqua !== undefined &&
					sAqua === "") && (sMatu !== undefined && sMatu === "")) {
				this.getView().getModel("ObjectPageModel").setProperty("/Amend", "");
				this.getView().getModel("ObjectPageModel").setProperty("/Ebom", "");
				this.getView().getModel("ObjectPageModel").setProperty("/Alert", "");
				this.getView().getModel("ObjectPageModel").setProperty("/Aqua", "");
				sap.ui.getCore().getModel("MULTIINPUTMODEL").setData({
					aMultiInput: []
				});
				this.getView().getModel("ObjectPageModel").setProperty("/Matu", "");
			}

			var bEditable = oObjectPageModel.getProperty("/bEditable");
			if (bEditable) {
				this.getView().getModel("ObjectPageModel").setProperty("/bEditable", bEditable);
			} else {
				this.getView().getModel("ObjectPageModel").setProperty("/bEditable", false);
			}
		}
	},
	f4oDataCallsforPVBF: function (entitySet, oFilter) {
		var that = this;
		this._DocF4Model = this.getOwnerComponent().getModel("Custom_Model");
		this._DocF4Model.read(entitySet, {
			filters: [oFilter],
			success: function (oRetrievedResult) {
				var F4List = {
					"F4List": oRetrievedResult.results
				};
				that.PVBfrEvltn = new sap.ui.model.json.JSONModel();
				that.PVBfrEvltn.setSizeLimit(1000000);
				that.PVBfrEvltn.setData(F4List);

			}.bind(that),
			error: function (oError) {}.bind(that)
		});
	},
	f4oDataCalls: function (entitySet) {
		var that = this;
		this._DocF4Model = this.getOwnerComponent().getModel("Custom_Model");

		if ((entitySet == "/ZSDOKNRVH_C" && this.DocNoF4Model == undefined) || (entitySet == "/ZSDOKARVH_C" && this.DocTypeF4Model ==
				undefined) || (entitySet == "/ZSDOKTLVH_C" && this.DocPartF4Model == undefined) || (entitySet == "/ZSDOKVRVH_C" && this.DocVersionF4Model ==
				undefined)) {
			this._DocF4Model.read(entitySet, {
				success: function (oRetrievedResult) {
					var F4List = {
						"F4List": oRetrievedResult.results
					};
					if (entitySet == "/ZSDOKNRVH_C") {
						that.DocNoF4Model = new sap.ui.model.json.JSONModel()
						that.DocNoF4Model.setSizeLimit(1000000);
						that.DocNoF4Model.setData(F4List);
					}
					if (entitySet == "/ZSDOKARVH_C") {
						that.DocTypeF4Model = new sap.ui.model.json.JSONModel()
						that.DocTypeF4Model.setSizeLimit(1000000);
						that.DocTypeF4Model.setData(F4List);
					}
					if (entitySet == "/ZSDOKTLVH_C") {
						that.DocPartF4Model = new sap.ui.model.json.JSONModel()
						that.DocPartF4Model.setSizeLimit(1000000);
						that.DocPartF4Model.setData(F4List);
					}
					if (entitySet == "/ZSDOKVRVH_C") {
						that.DocVersionF4Model = new sap.ui.model.json.JSONModel()
						that.DocVersionF4Model.setSizeLimit(1000000);
						that.DocVersionF4Model.setData(F4List);
					}

				}.bind(that),
				error: function (oError) {}.bind(that)
			});
		}
	},

	onCopyPress: function () {
		this.bEditable = true;
		var oModel = sap.ui.getCore().getModel("ObjectPageModel");
		oModel.setProperty("/bEditable", true);
		oModel.updateBindings(true);
	},

	onFetchPress: function (oEvent) {
		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
		var sMaterial = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-input");
		var sPlant = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-input");
		var sProdverText = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionText::Field-input");
		if (sMaterial && sPlant && sProdverText) {
			sMaterial = sMaterial.getValue();
			sPlant = sPlant.getValue();
			sProdverText = sProdverText.getValue();
			if (sMaterial !== "" && sPlant !== "" && sProdverText !== "") {
				var oDataModel = sap.ui.getCore().getModel("MainModel");
				oDataModel.read("/ZPP_GET_PVSet(Material='" + sMaterial + "',Plant='" + sPlant + "')", {
					success: function (oData, oResponse) {
						var sProductionVersion = oData.Version;
						var oObjectPageModel = sap.ui.getCore().getModel("ObjectPageModel");
						sap.ui.getCore().byId(sViewId +
							"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionForEdit::Field-input").setValue(
							sProductionVersion);
						oObjectPageModel.setProperty("/Material", sMaterial);
						oObjectPageModel.setProperty("/Plant", sPlant);
						oObjectPageModel.setProperty("/Version", sProductionVersion);
					},
					error: function (oError) {
						sap.m.MessageToast.show("Error reading the data");
					}
				});
			} else {
				sap.m.MessageToast.show("Please enter missing fields");
			}
		}
	},

	onEditPress: function () {
		// Begin Code Block -- Ramlath -- Fiori_573

		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";

		//FT059491A -- SHalini Rana
		var oLockStatus = sap.ui.getCore().byId(
			sViewId + "--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field"
		)
		if (oLockStatus) {
			oLockStatus.attachChange(this.onLockChange, this);
		}
		const oViewModel = this.getView().getModel("viewModel")
		oViewModel.setProperty("/isEditable", true) //added by : Shalini  Rana(FT059491A)- E197 part3
		this.objModel.setProperty("/bEdit", true) //added by : Shalini  Rana(FT059491A)- E197 part3
		this.objModel.setProperty("/bCreateFlag", false);
		const isSaved = this.objModel.getProperty("/bSaved") //added by : Shalini  Rana(FT059491A)- E197 part3
		if (isSaved) {
			// this.getHeaderData();
			this.getHeaderData().then(function (data) {
				var oModel = sap.ui.getCore().getModel("ObjectPageModel");
				// oModel.setData(data);
				// oModel.updateBindings(true);
				oModel.setProperty("/Aenst", data.Aenst)
				oModel.setProperty("/Alert", data.Alert)
				oModel.setProperty("/Amend", data.Amend)
				oModel.setProperty("/Aqua", data.Aqua)
				oModel.setProperty("/Devno", data.Devno)
				oModel.setProperty("/Disabled", data.Disabled)
				oModel.setProperty("/Dktxt", data.Dktxt)
				oModel.setProperty("/Dokar", data.Dokar)
				oModel.setProperty("/Doknr", data.Doknr)
				oModel.setProperty("/Doktl", data.Doktl)
				oModel.setProperty("/Dokvr", data.Dokvr)
				oModel.setProperty("/Ebom", data.Ebom)
				oModel.setProperty("/LinkToCM", data.LinkToCM)
				oModel.setProperty("/Material", data.Material)
				oModel.setProperty("/Matu", data.Matu)
				oModel.setProperty("/Mksp", data.Mksp)
				oModel.setProperty("/Newenddate", data.Newenddate)
				oModel.setProperty("/Newlockstatus", data.Newlockstatus)
				oModel.setProperty("/Newstartdate", data.Newstartdate)
				oModel.setProperty("/Oldenddate", data.Oldenddate)
				oModel.setProperty("/Oldlockstatus", data.Oldlockstatus)
				oModel.setProperty("/Oldstartdate", data.Oldstartdate)

				oModel.setProperty("/Plant", data.Plant)
				oModel.setProperty("/Version", data.Version)
				oModel.setProperty("/Zzplanning", data.Zzplanning)
				oModel.setProperty("/Zzprevpv", data.Zzprevpv)
				oModel.setProperty("/bSaved", false)
				oModel.setProperty("/bEdit", true)

				this.setFieldMode()
					// sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEdit", false)

			}.bind(this));

		} else {
			this.setFieldMode()
		}
		this.oMaterial = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-text").getText();
		this.oPlant = sap.ui.getCore().byId(sViewId +
				"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-text")
			.getText();
		this.oVersion = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionForEdit::Field-text").getText();

		this.OldStartDate = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ValidityStartDate::Field-text").getText().split(".");
		this.OldStartDate = this.OldStartDate[2] + this.OldStartDate[1] + this.OldStartDate[0];
		this.OldEndDate = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ValidityEndDate::Field-text").getText().split(".");
		this.OldEndDate = this.OldEndDate[2] + this.OldEndDate[1] + this.OldEndDate[0];
		this.OldLockStatus = sap.ui.getCore().byId(sViewId +
				"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-text").getBindingContext().getObject()
			.ProductionVersionIsLocked;
		//End Code Block -- Ramlath -- Fiori_573

		// FT059443A - No longer needed - Using standadard binding to enable custom fields
		// sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", true);
	},

	// FT059443A - No longer needed - Using standadard binding to enable custom fields
	// onCancelPress: function () {
	// 	sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
	// },

	onSaveCustom: function () {
		// Execute Custom Save Logic
		var oPayload, oEntry;
		var oDataModel = sap.ui.getCore().getModel("MainModel");
		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
		sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bSaved", true) //added by : Shalini  Rana(FT059491A)- E197 part3

		//Begin Code Block -- Ramlath -- Fiori_573
		// this.NewStartDate = sap.ui.getCore().byId(sViewId +
		// 	"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ValidityStartDate::Field-datePicker").getValue().split(".");
		// this.NewStartDate = this.NewStartDate[2] + this.NewStartDate[1] + this.NewStartDate[0];
		// this.NewEndDate = sap.ui.getCore().byId(sViewId +
		// 	"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ValidityEndDate::Field-datePicker").getValue().split(".");
		// this.NewEndDate = this.NewEndDate[2] + this.NewEndDate[1] + this.NewEndDate[0];
		// this.NewLockStatus = sap.ui.getCore().byId(sViewId +
		// 	"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria2::ProductionVersionIsLocked::Field-comboBoxEdit").getSelectedKey();

		// var oObject = {
		// 	"Material": this.oMaterial,
		// 	"Plant": this.oPlant,
		// 	"Version": this.oVersion,
		// 	"Oldstartdate": this.OldStartDate,
		// 	"Newstartdate": this.NewStartDate,
		// 	"Oldenddate": this.OldEndDate,
		// 	"Newenddate": this.NewEndDate,
		// 	"Oldlockstatus": this.OldLockStatus,
		// 	"Newlockstatus": this.NewLockStatus,
		// };

		// oDataModel.create("/ZPP_HISTORYSet", oObject, {
		// 	method: "POST",
		// 	success: function (oData, oResponse) {
		// 		sap.m.MessageToast.show("Updated Successfully");
		// 		sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
		// 	},
		// 	error: function (oResponse) {
		// 		sap.m.MessageToast.show("Not Updated Successfully");
		// 	}
		// });

		//End Code Block -- Ramlath -- Fiori_573

		var sMaterial = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-input");
		var sPlant = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-input");
		var sProdverText = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionText::Field-input");
		var sPrdVrTextEdit = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionText::Field");
		var sVersionEdit = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionForEdit::Field");
		var sVersion = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionForEdit::Field-input");

		var bCreateFlag = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/bCreateFlag");
		var sMaterialFromModel = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Material");
		var sPlantFromModel = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Plant");
		var sVersionFromModel = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Version");
		var idToken1 = sap.ui.getCore().byId("__xmlview0--idMultiInput");
		var idToken2 = sap.ui.getCore().byId("__xmlview1--idMultiInput");
		var idToken3 = sap.ui.getCore().byId("__xmlview2--idMultiInput");
		var idToken4 = sap.ui.getCore().byId("__xmlview3--idMultiInput");
		var idToken5 = sap.ui.getCore().byId("__xmlview4--idMultiInput");
		var idToken6 = sap.ui.getCore().byId("__xmlview5--idMultiInput");
		var aTokens;
		if (idToken1 && idToken1.getTokens()) {
			aTokens = idToken1.getTokens();
		}
		if (idToken2 && idToken2.getTokens()) {
			aTokens = idToken2.getTokens();
		}
		if (idToken3 && idToken3.getTokens()) {
			aTokens = idToken3.getTokens();
		}
		if (idToken4 && idToken4.getTokens()) {
			aTokens = idToken4.getTokens();
		}
		if (idToken5 && idToken5.getTokens()) {
			aTokens = idToken5.getTokens();
		}
		if (idToken6 && idToken6.getTokens()) {
			aTokens = idToken6.getTokens();
		}
		var aTokensData = [],
			sDevNumbers = "";
		if (aTokens != undefined) {
			if (aTokens.length !== 0) {
				aTokens.forEach(function (oItem) {
					aTokensData.push(oItem.getText());
				});
				sDevNumbers = aTokensData.join(",");
			}
		}

		if (bCreateFlag) {
			if ((sPrdVrTextEdit && sPrdVrTextEdit.getValue() === "") && (sVersionEdit && sVersionEdit.getValue() === "")) {
				sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", true);
			} else {
				sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
			}
			if (sMaterial && sPlant && sProdverText && sVersion) {
				sMaterial = sMaterial.getValue();
				sPlant = sPlant.getValue();
				sProdverText = sProdverText.getValue();
				sVersion = sVersion.getValue();
				if (sMaterial !== "" && sPlant !== "" && sProdverText !== "" && sVersion !== "") {
					sap.ui.getCore().getModel("ObjectPageModel").setProperty("/Material", sMaterial);
					sap.ui.getCore().getModel("ObjectPageModel").setProperty("/Plant", sPlant);
					sap.ui.getCore().getModel("ObjectPageModel").setProperty("/Version", sVersion);
					sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
					oPayload = sap.ui.getCore().getModel("ObjectPageModel").getData();
					/*oEntry = {
						Material: oPayload.Material,
						Plant: oPayload.Plant,
						Version: oPayload.Version,
						Amend: oPayload.Amend,
						Ebom: oPayload.Ebom,
						Devno: sDevNumbers,
						Alert: oPayload.Alert,
						Aqua: oPayload.Aqua,
						Matu: oPayload.Matu
					};*/
					//Begin Code Block -- Ramlath -- Fiori_573

					/* Changes done by : Shalini Rana(FT059491A)
					Removed fields :Oldstartdate,Newstartdate, Oldenddate,Newenddate, Oldlockstatus,Newlockstatus) from Payload as
					not required at the time of creation */

					oEntry = {
						Material: oPayload.Material,
						Plant: oPayload.Plant,
						Version: oPayload.Version,
						Amend: oPayload.Amend,
						Ebom: oPayload.Ebom,
						Devno: sDevNumbers,
						Alert: oPayload.Alert,
						Aqua: oPayload.Aqua,
						Matu: oPayload.Matu,
						// Oldstartdate: this.OldStartDate,
						// Newstartdate: this.NewStartDate,
						// Oldenddate: this.OldEndDate,
						// Newenddate: this.NewEndDate,
						// Oldlockstatus: this.OldLockStatus,
						// Newlockstatus: this.NewLockStatus,
						Doknr: oPayload.Doknr,
						Dokar: oPayload.Dokar,
						Doktl: oPayload.Doktl,
						Dokvr: oPayload.Dokvr,
						Dktxt: oPayload.Dktxt,
						Zzprevpv: oPayload.Zzprevpv,
						Zzplanning: oPayload.Zzplanning
					};
					//End Code Block -- Ramlath -- Fiori_573
					// setTimeout(function() {
					oDataModel.update("/ZPP_HEADERSet(Material='" + oPayload.Material + "',Plant='" + oPayload.Plant + "',Version='" + oPayload.Version +
						"')", oEntry, null, {
							success: function () {
								//done = true;
								sap.m.MessageToast.show("Updated Successfully");
								sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
							},
							error: function () {
								sap.m.MessageToast.show("Not Updated Successfully");
							}
						});
					// }, 5000);
					// var docpayload = {
					// 	Material: oPayload.Material,
					// 	Plant: oPayload.Plant,
					// 	Version: oPayload.Version,
					// 	Doknr: oPayload.Doknr,
					// 	Dokar: oPayload.Dokar,
					// 	Doktl: oPayload.Doktl,
					// 	Dokvr: oPayload.Dokvr,
					// 	Dktxt: oPayload.Dktxt
					// };
					// oDataModel.create("/ZPP_DOCRECORDSet", docpayload, null, {
					// 	success: function () {

					// 		//done = true;
					// 		sap.m.MessageToast.show("Updated Successfully");
					// 		sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
					// 	},
					// 	error: function () {
					// 		sap.m.MessageToast.show("Not Updated Successfully");
					// 	}
					// });
					// var planningpayload = {
					// 	Material: oPayload.Material,
					// 	Plant: oPayload.Plant,
					// 	Version: oPayload.Version,
					// 	Zzprevpv: oPayload.Zzprevpv,
					// 	Zzplanning: oPayload.Zzplanning
					// };
					// oDataModel.update("/ZPP_PLANDATASet(Material='" + oPayload.Material + "',Plant='" + oPayload.Plant + "',Version='" + oPayload.Version +
					// 	"')", planningpayload, null, {
					// 		success: function () {

					// 			//done = true;
					// 			sap.m.MessageToast.show("Updated Successfully");
					// 			sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
					// 		},
					// 		error: function () {
					// 			sap.m.MessageToast.show("Not Updated Successfully");
					// 		}
					// 	});

				}
			}
			if (sMaterialFromModel !== "" && sPlantFromModel !== "" && sVersionFromModel !== "") {
				oPayload = sap.ui.getCore().getModel("ObjectPageModel").getData();
				/*oEntry = {
					Material: oPayload.Material,
					Plant: oPayload.Plant,
					Version: oPayload.Version,
					Amend: oPayload.Amend,
					Ebom: oPayload.Ebom,
					Devno: sDevNumbers,
					Alert: oPayload.Alert,
					Aqua: oPayload.Aqua,
					Matu: oPayload.Matu
				};*/
				//Begin Code Block -- Ramlath -- Fiori_573

				/*Removed fields :Oldstartdate,Newstartdate, Oldenddate,Newenddate, Oldlockstatus,Newlockstatus) from Payload as not required at the time of creation */
				oEntry = {
					Material: oPayload.Material,
					Plant: oPayload.Plant,
					Version: oPayload.Version,
					Amend: oPayload.Amend,
					Ebom: oPayload.Ebom,
					Devno: sDevNumbers,
					Alert: oPayload.Alert,
					Aqua: oPayload.Aqua,
					Matu: oPayload.Matu,
					// Oldstartdate: this.OldStartDate,
					// Newstartdate: this.NewStartDate,
					// Oldenddate: this.OldEndDate,
					// Newenddate: this.NewEndDate,
					// Oldlockstatus: this.OldLockStatus,
					// Newlockstatus: this.NewLockStatus,
					Doknr: oPayload.Doknr,
					Dokar: oPayload.Dokar,
					Doktl: oPayload.Doktl,
					Dokvr: oPayload.Dokvr,
					Dktxt: oPayload.Dktxt,
					Zzprevpv: oPayload.Zzprevpv,
					Zzplanning: oPayload.Zzplanning
				};
				//End Code Block -- Ramlath -- Fiori_573
				// setTimeout(function() {
				oDataModel.update("/ZPP_HEADERSet(Material='" + oPayload.Material + "',Plant='" + oPayload.Plant + "',Version='" + oPayload.Version +
					"')", oEntry, null, {
						success: function () {
							sap.m.MessageToast.show("Updated Successfully");
							sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
						},
						error: function () {
							sap.m.MessageToast.show("Not Updated Successfully");
						}
					});

				// }, 5000);

				// var docpayload = {
				// 	Material: oPayload.Material,
				// 	Plant: oPayload.Plant,
				// 	Version: oPayload.Version,
				// 	Doknr: oPayload.Doknr,
				// 	Dokar: oPayload.Dokar,
				// 	Doktl: oPayload.Doktl,
				// 	Dokvr: oPayload.Dokvr,
				// 	Dktxt: oPayload.Dktxt
				// };
				// oDataModel.create("/ZPP_DOCRECORDSet", docpayload, null, {
				// 	success: function () {

				// 		//done = true;
				// 		sap.m.MessageToast.show("Updated Successfully");
				// 		sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
				// 	},
				// 	error: function () {
				// 		sap.m.MessageToast.show("Not Updated Successfully");
				// 	}
				// });

				// var planningpayload = {
				// 	Material: oPayload.Material,
				// 	Plant: oPayload.Plant,
				// 	Version: oPayload.Version,
				// 	Zzprevpv: oPayload.Zzprevpv,
				// 	Zzplanning: oPayload.Zzplanning
				// };
				// oDataModel.update("/ZPP_PLANDATASet(Material='" + oPayload.Material + "',Plant='" + oPayload.Plant + "',Version='" + oPayload.Version +
				// 	"')", planningpayload, null, {
				// 		success: function () {

				// 			//done = true;
				// 			sap.m.MessageToast.show("Updated Successfully");
				// 			sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
				// 		},
				// 		error: function () {
				// 			sap.m.MessageToast.show("Not Updated Successfully");
				// 		}
				// 	});

			}
		} else {
			if ((sPrdVrTextEdit && sPrdVrTextEdit.getValue() === "") && (sVersionEdit && sVersionEdit.getValue() === "")) {
				sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", true);
			} else {
				sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
			}

			oPayload = sap.ui.getCore().getModel("ObjectPageModel").getData();
			oPayload.Version = sap.ui.getCore().getModel("ObjectPageModel").getProperty("/Version");
			if (sVersion && sVersion.getValue() !== "") {
				oPayload.Version = sVersion.getValue();
			}
			/*oEntry = {
				Material: oPayload.Material,
				Plant: oPayload.Plant,
				Version: oPayload.Version,
				Amend: oPayload.Amend,
				Ebom: oPayload.Ebom,
				Devno: sDevNumbers,
				Alert: oPayload.Alert,
				Aqua: oPayload.Aqua,
				Matu: oPayload.Matu
			};*/
			//Begin Code Block -- Ramlath -- Fiori_573
			oEntry = {
				Material: this.oMaterial,
				Plant: this.oPlant,
				Version: this.oVersion,
				Amend: oPayload.Amend,
				Ebom: oPayload.Ebom,
				Devno: sDevNumbers,
				Alert: oPayload.Alert,
				Aqua: oPayload.Aqua,
				Matu: oPayload.Matu,
				Oldstartdate: this.OldStartDate,
				Newstartdate: this.NewStartDate,
				Oldenddate: this.OldEndDate,
				Newenddate: this.NewEndDate,
				Oldlockstatus: this.OldLockStatus,
				Newlockstatus: this.NewLockStatus,
				Doknr: oPayload.Doknr,
				Dokar: oPayload.Dokar,
				Doktl: oPayload.Doktl,
				Dokvr: oPayload.Dokvr,
				Dktxt: oPayload.Dktxt,
				Zzprevpv: oPayload.Zzprevpv,
				Zzplanning: oPayload.Zzplanning
			};
			//End Code Block -- Ramlath -- Fiori_573
			// setTimeout(function() {
			oDataModel.update("/ZPP_HEADERSet(Material='" + this.oMaterial + "',Plant='" + this.oPlant + "',Version='" + this.oVersion +
				"')", oEntry, null, {
					success: function () {
						sap.m.MessageToast.show("Updated Successfully");
						sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
					},
					error: function () {
						sap.m.MessageToast.show("Not Updated Successfully");
					}
				});
			// }, 5000);
			// var docpayload = {
			// 	Material: this.oMaterial,
			// 	Plant: this.oPlant,
			// 	Version: this.oVersion,
			// 	Doknr: oPayload.Doknr,
			// 	Dokar: oPayload.Dokar,
			// 	Doktl: oPayload.Doktl,
			// 	Dokvr: oPayload.Dokvr,
			// 	Dktxt: oPayload.Dktxt
			// };
			// oDataModel.create("/ZPP_DOCRECORDSet", docpayload, null, {
			// 	success: function () {

			// 		//done = true;
			// 		sap.m.MessageToast.show("Updated Successfully");
			// 		sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
			// 	},
			// 	error: function () {
			// 		sap.m.MessageToast.show("Not Updated Successfully");
			// 	}
			// });

			// var planningpayload = {
			// 	Material: this.oMaterial,
			// 	Plant: this.oPlant,
			// 	Version: this.oVersion,
			// 	Zzprevpv: oPayload.Zzprevpv,
			// 	Zzplanning: oPayload.Zzplanning
			// };
			// oDataModel.update("/ZPP_PLANDATASet(Material='" + this.oMaterial + "',Plant='" + this.oPlant + "',Version='" + this.oVersion +
			// 	"')", planningpayload, null, {
			// 		success: function () {

			// 			//done = true;
			// 			sap.m.MessageToast.show("Updated Successfully");
			// 			sap.ui.getCore().getModel("ObjectPageModel").setProperty("/bEditable", false);
			// 		},
			// 		error: function () {
			// 			sap.m.MessageToast.show("Not Updated Successfully");
			// 		}
			// 	});

		}
	},
	getHeaderData: function () {
		const {
			Material,
			Plant,
			Version
		} = this.objModel.oData;
		return new Promise(function (resolve, reject) {
			var sPath = "/ZPP_HEADERSet(Material='" + Material + "',Plant='" + Plant + "',Version='" + Version +
				"')"
			const oDataModel = sap.ui.getCore().getModel("MainModel");
			oDataModel.read(sPath, {
				success: function (oData) {
					resolve(oData);
				},
				error: function (oError) {
					reject(oError);
				}

			});
		}.bind(this));

	},
	onEditCustom: function () {},
	onClickActionHistory: function (oEvent) {
		//Begin Code Block -- Fiori_573
		this.oMaterial = sap.ui.getCore().byId(
			"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-text"
		).getText();

		this.oPlant = sap.ui.getCore().byId(
			"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-text"
		).getText();

		this.oVersion = sap.ui.getCore().byId(
			"sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionForEdit::Field-text"
		).getText();

		var xnavservice = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
			"CrossApplicationNavigation");
		var href = (xnavservice && xnavservice.hrefForExternal({
			target: {
				semanticObject: "zso_dts_zppvm",
				action: "display"
			},
			params: {
				"S_MATNR-LOW": this.oMaterial,
				"P_WERKS": this.oPlant,
				"P_VERID": this.oVersion
			}
		}));
		var finalUrl = window.location.href.split("#")[0] + href;
		sap.m.URLHelper.redirect(finalUrl, true);
		//End Code Block -- Fiori_573
	},
	onComboBoxSelectionChange: function (oEvent) {
		var oSource = oEvent.getSource();
		var sSelectedKey = oEvent.getSource().getSelectedKey();
		oSource.setSelectedKey(sSelectedKey);

	},
	onAlertSelectionChange: function (oEvent) {
		var oSource = oEvent.getSource();
		var sSelectedKey = oEvent.getSource().getSelectedKey();
		oSource.setSelectedKey(sSelectedKey);

	},
	onSelectCheckBOX: function (oEvent) {
		var oSource = oEvent.getSource();
		var sSelected = oSource.getSelected();
		if (sSelected === true) {
			sap.ui.getCore().getModel("ObjectPageModel").setProperty("/Aqua", "X");
		} else {
			sap.ui.getCore().getModel("ObjectPageModel").setProperty("/Aqua", "");
		}

	},
	onChange: function (oEvent) {
		this.change = true;
		this.onValueHelpRequested(oEvent);
	},
	onF4Ruested: function (oEvent) {
		this.change = false;
		this.onValueHelpRequested(oEvent);
	},
	onChangeProdBeforeEvol: function (oEvent) {
		this.change = true;
		this.onValueHelpRequested(oEvent);
	},
	onF4RuestedProdBeforeEvol: function (oEvent) {
		this.change = false;
		this.onValueHelpRequested(oEvent);
	},
	onValueHelpRequested: function (oEvent) {
		var searchStr = oEvent.getSource().getValue();
		var key = null;
		var key1 = null;
		var key2 = null;
		var tile = null;
		this.oFilter = null;
		var entitySet = null;
		var label = null;
		var label1 = null;
		var field = null;
		var that = this;
		var frangmentName = null;
		var valuststeId = null;
		var valuestateModel = null;

		this._oMultiInput = oEvent.getSource();
		if (oEvent.getSource().getId().includes("idProdVerBfrEvolution")) {
			entitySet = "/ZPP_PLANDATASet";
			this.oFilter = [];

			var material = this.oMaterial;
			var plant = this.oPlant;
			var ViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
			if (material == undefined && sap.ui.getCore().byId(ViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-input") != undefined)
				material = sap.ui.getCore().byId(ViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-input").getValue();
			if (plant == undefined && sap.ui.getCore().byId(ViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-input") != undefined)
				plant = sap.ui.getCore().byId(ViewId + "--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-input").getValue();
			if (material == undefined)
				material = sap.ui.getCore().byId(ViewId +
					"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-text")
				.getText();
			if (plant == undefined)
				plant = sap.ui.getCore().byId(ViewId + "--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-text").getText();

			this.oFilter.push(new sap.ui.model.Filter({
				filters: [
					//new sap.ui.model.Filter('Zzprevpv', sap.ui.model.FilterOperator.Contains, searchStr),
					new sap.ui.model.Filter('Material', sap.ui.model.FilterOperator.EQ, material),
					new sap.ui.model.Filter('Plant', sap.ui.model.FilterOperator.EQ, plant)
				],
				and: true
			}));
			label = "{i18n>ProdVerBfrEvolution}";
			label1 = "ProdVerBfrEvolution";
			field = "F4ListModel>Version";
			key = "Zzprevpv";
			key1 = "Zzprevpv";
			key2 = "Version";
			valuststeId = "idProdVerBfrEvolution";
			tile = this.getView().getModel("i18n").getResourceBundle().getText("ProdVerBfrEvolution");
			frangmentName = "sed.mpe.prodver.manages1.ext.fragment.ValueHelpDialogFilterbarProdVerBfrEvolution";
			valuestateModel = "idModel1";

			if (this.PVBfrEvltn == undefined && this.oMaterial != undefined && this.oPlant != undefined && this.oMaterial != "" && this.oPlant !=
				"")
				this.f4oDataCallsforPVBF(entitySet, this.oFilter);

			if ((this.oMaterial == undefined && this.oPlant == undefined) && (material != "" && plant != ""))
				this.f4oDataCallsforPVBF(entitySet, this.oFilter);
		}
		if (oEvent.getSource().getId().includes("idDocNo")) {
			entitySet = "/ZSDOKNRVH_C";
			this.oFilter = new sap.ui.model.Filter('doknr', sap.ui.model.FilterOperator.Contains, searchStr);
			label = "{i18n>DocNo}";
			label1 = "DocNo";
			field = "F4ListModel>doknr";
			key = "doknr";
			key2 = "doknr";
			key1 = "Doknr";
			valuststeId = "idDocNo";
			tile = this.getView().getModel("i18n").getResourceBundle().getText("DocNo");
			frangmentName = "sed.mpe.prodver.manages1.ext.fragment.ValueHelpDialogFilterbarDocNum";
			valuestateModel = "idModel";
		}
		if (oEvent.getSource().getId().includes("idDocType")) {
			entitySet = "/ZSDOKARVH_C";
			this.oFilter = new sap.ui.model.Filter('dokar', sap.ui.model.FilterOperator.Contains, searchStr);
			label = "{i18n>DocType}";
			label1 = "DocType";
			field = "F4ListModel>dokar";
			key = "dokar";
			key2 = "dokar";
			key1 = "Dokar";
			valuststeId = "idDocType";
			tile = this.getView().getModel("i18n").getResourceBundle().getText("DocType");
			frangmentName = "sed.mpe.prodver.manages1.ext.fragment.ValueHelpDialogFilterbarDocType";
			valuestateModel = "idModel";
		}
		if (oEvent.getSource().getId().includes("idDocPart")) {
			entitySet = "/ZSDOKTLVH_C";
			this.oFilter = new sap.ui.model.Filter('doktl', sap.ui.model.FilterOperator.Contains, searchStr);
			label = "{i18n>DocPart}";
			label1 = "DocPart";
			field = "F4ListModel>doktl";
			key = "doktl";
			key2 = "doktl";
			key1 = "Doktl";
			valuststeId = "idDocPart";
			tile = this.getView().getModel("i18n").getResourceBundle().getText("DocPart");
			frangmentName = "sed.mpe.prodver.manages1.ext.fragment.ValueHelpDialogFilterbarDocPart";
			valuestateModel = "idModel";
		}

		if (oEvent.getSource().getId().includes("idDocVersion")) {
			entitySet = "/ZSDOKVRVH_C";
			this.oFilter = new sap.ui.model.Filter('dokvr', sap.ui.model.FilterOperator.Contains, searchStr);
			label = "{i18n>DocVersion}";
			label1 = "DocVersion";
			field = "F4ListModel>dokvr";
			key = "dokvr";
			key2 = "dokvr";
			key1 = "Dokvr";
			valuststeId = "idDocVersion";
			tile = this.getView().getModel("i18n").getResourceBundle().getText("DocVersion");
			frangmentName = "sed.mpe.prodver.manages1.ext.fragment.ValueHelpDialogFilterbarDocVersion";
			valuestateModel = "idModel";
		}
		this.keyField = key;
		this.keyField1 = key1;
		this.keyField2 = key2;
		this.valuststeId = valuststeId;
		this.valuestateModel = valuestateModel;
		this.dynamicF4Model = new sap.ui.model.json.JSONModel();
		var keytitle = {
			title: tile,
			key: key2
		};
		this.dynamicF4Model.setData(keytitle);
		var oView = this.getView();
		oView.setModel(this.dynamicF4Model, "dynamicF4Model");
		this._DocF4Model = this.getOwnerComponent().getModel("Custom_Model");

		////////////////////////////////////////////////////////////////////////////
		this.DocF4ListModel = new sap.ui.model.json.JSONModel();
		if (oEvent.getSource().getId().includes("idDocNo"))
			this.DocF4ListModel = this.DocNoF4Model;
		if (oEvent.getSource().getId().includes("idDocType"))
			this.DocF4ListModel = this.DocTypeF4Model;
		if (oEvent.getSource().getId().includes("idDocPart"))
			this.DocF4ListModel = this.DocPartF4Model;
		if (oEvent.getSource().getId().includes("idDocVersion"))
			this.DocF4ListModel = this.DocVersionF4Model;
		if (oEvent.getSource().getId().includes("idProdVerBfrEvolution")) {
			this.DocF4ListModel = this.PVBfrEvltn;
		}
		oView.setModel(this.DocF4ListModel, "F4ListModel");

		/////////////////////////
		this.oColModel = new sap.ui.model.json.JSONModel();
		var data = {
			"cols": [{
				"label": label,
				"template": field,
			}]
		};
		this.oColModel.setData(data);
		var aCols = this.oColModel.getData().cols;
		this._oBasicSearchField = new sap.m.SearchField({
			showSearchButton: false
		});
		this._oBasicSearchField.setValue(this._oMultiInput.getValue());

		this._oBasicSearchField.attachSearch(function (oEvent) {
			var sSearchQuery = oEvent.getSource().getValue(),
				aSelectionSet = this._oValueHelpDialog.getFilterBar().getAllFilterItems();
			//aSelectionSet = oEvent.getParameter("selectionSet");
			this.implementSearch(sSearchQuery, aSelectionSet);
		});
		this._oValueHelpDialog = sap.ui.xmlfragment(frangmentName, this);
		this.getView().addDependent(this._oValueHelpDialog);

		this._oValueHelpDialog.setRangeKeyFields([{
			label: this.getView().getModel("i18n").getResourceBundle().getText(label1),
			key: key2,
			type: "string",
			typeInstance: new sap.ui.model.type.String({}, {
				maxLength: 20
			})
		}]);

		var oFilterBar = this._oValueHelpDialog.getFilterBar();
		oFilterBar.setFilterBarExpanded(true);
		oFilterBar.setBasicSearch(this._oBasicSearchField);
		//oFilterBar.getBasicSearch().attachSearch(this.onFilterBarSearch);
		this._oValueHelpDialog.getTableAsync().then(function (oTable) {
			oTable.setModel(this.DocF4ListModel, "F4ListModel");
			oTable.setModel(this.oColModel, "columns");
			oTable.setSelectionMode("Single");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "F4ListModel>/F4List");
			}

			if (oTable.bindItems) {
				oTable.bindAggregation("items", "F4ListModel>/F4List", function () {
					return new sap.m.ColumnListItem({
						cells: aCols.map(function (column) {
							return new sap.m.Label({
								text: "{" + column.template + "}"
							});
						})
					});
				});
			}
			this._oValueHelpDialog.update();
		}.bind(this));
		var sSearchQuery = this._oBasicSearchField.getValue();
		var i = 0;
		var count = 0;
		var match = 0;
		var matnrkey;
		for (i = 0; i < this.getView().getModel("F4ListModel").oData.F4List.length; i++) {
			if (this.getView().getModel("F4ListModel").oData.F4List[i][key2].toUpperCase().includes(sSearchQuery.toUpperCase())) { ///////////////////////
				count++;
			}
			if (this.getView().getModel("F4ListModel").oData.F4List[i][key2].toUpperCase() == sSearchQuery.toUpperCase()) { //////////////////////////////
				match++;
				matnrkey = this.getView().getModel("F4ListModel").oData.F4List[i][key2]; ////////////////////////////////
				break;
			}

		}

		//this._oValueHelpDialog.open();

		var aSelectionSet = this._oValueHelpDialog.getFilterBar().getAllFilterItems();
		this.implementSearch(sSearchQuery, aSelectionSet);
		if (match > 0 && this.change) {
			this._setSelectedMaterialAndUpdateInput(matnrkey);

			this.objModel.oData[this.keyField1] = matnrkey;
			this.objModel.updateBindings(this);
			this.getView().getModel("ObjectPageModel").oData[this.keyField1] = matnrkey;
			this.getView().getModel("ObjectPageModel").updateBindings(true);

			sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
				.None);
			if (key != "Zzprevpv") {
				if (this.documentfieldsMandotoryCheck()) {
					this.updateDocDescription();
				}
			}

		} else if (count > 0)
			this._oValueHelpDialog.open();
		else {
			sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("no" + label1, [sSearchQuery]));
			this.objModel.oData[this.keyField1] = "";
			this.objModel.updateBindings(true);
			this.getView().getModel("ObjectPageModel").oData[that.keyField1] = "";
			this.getView().getModel("ObjectPageModel").updateBindings(true);
			sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
				.None);
			//that._oMultiInput.setValue("");
		}
		/////////////////////////////////////////////////////////////////////////////

		// that._DocF4Model.read(entitySet, {
		// 	filters: [oFilter],
		// 	success: function (oRetrievedResult) {
		// 		that.DocF4ListModel = new sap.ui.model.json.JSONModel();
		// 		var F4List = {
		// 			"F4List": oRetrievedResult.results
		// 		};
		// 		that.DocF4ListModel.setSizeLimit(1000000);
		// 		that.DocF4ListModel.setData(F4List);
		// 		oView.setModel(that.DocF4ListModel, "F4ListModel");

		// 		/////////////////////////
		// 		that.oColModel = new sap.ui.model.json.JSONModel();
		// 		var data = {
		// 			"cols": [{
		// 				"label": label,
		// 				"template": field,
		// 			}]
		// 		};
		// 		that.oColModel.setData(data);
		// 		var aCols = that.oColModel.getData().cols;
		// 		that._oBasicSearchField = new sap.m.SearchField({
		// 			showSearchButton: false
		// 		});
		// 		that._oBasicSearchField.setValue(that._oMultiInput.getValue());

		// 		that._oBasicSearchField.attachSearch(function (oEvent) {
		// 			var sSearchQuery = oEvent.getSource().getValue(),
		// 				aSelectionSet = that._oValueHelpDialog.getFilterBar().getAllFilterItems();
		// 			//aSelectionSet = oEvent.getParameter("selectionSet");
		// 			that.implementSearch(sSearchQuery, aSelectionSet);
		// 		});
		// 		that._oValueHelpDialog = sap.ui.xmlfragment(frangmentName, that);
		// 		that.getView().addDependent(that._oValueHelpDialog);

		// 		that._oValueHelpDialog.setRangeKeyFields([{
		// 			label: that.getView().getModel("i18n").getResourceBundle().getText(label1),
		// 			key: key,
		// 			type: "string",
		// 			typeInstance: new sap.ui.model.type.String({}, {
		// 				maxLength: 20
		// 			})
		// 		}]);

		// 		var oFilterBar = that._oValueHelpDialog.getFilterBar();
		// 		oFilterBar.setFilterBarExpanded(true);
		// 		oFilterBar.setBasicSearch(that._oBasicSearchField);
		// 		//oFilterBar.getBasicSearch().attachSearch(this.onFilterBarSearch);
		// 		that._oValueHelpDialog.getTableAsync().then(function (oTable) {
		// 			oTable.setModel(that.DocF4ListModel, "F4ListModel");
		// 			oTable.setModel(that.oColModel, "columns");
		// 			oTable.setSelectionMode("Single");
		// 			if (oTable.bindRows) {
		// 				oTable.bindAggregation("rows", "F4ListModel>/F4List");
		// 			}

		// 			if (oTable.bindItems) {
		// 				oTable.bindAggregation("items", "F4ListModel>/F4List", function () {
		// 					return new sap.m.ColumnListItem({
		// 						cells: aCols.map(function (column) {
		// 							return new sap.m.Label({
		// 								text: "{" + column.template + "}"
		// 							});
		// 						})
		// 					});
		// 				});
		// 			}

		// 			that._oValueHelpDialog.update();
		// 		}.bind(that));

		// 		//that._oValueHelpDialog.setTokens(that._oMultiInput.getTokens());

		// 		var sSearchQuery = that._oBasicSearchField.getValue();
		// 		var i = 0;
		// 		var count = 0;
		// 		var match = 0;
		// 		var matnrkey;
		// 		for (i = 0; i < that.getView().getModel("F4ListModel").oData.F4List.length; i++) {
		// 			if (that.getView().getModel("F4ListModel").oData.F4List[i][key].toUpperCase().includes(sSearchQuery.toUpperCase())) { ///////////////////////
		// 				count++;
		// 			}
		// 			if (that.getView().getModel("F4ListModel").oData.F4List[i][key].toUpperCase() == sSearchQuery.toUpperCase()) { //////////////////////////////
		// 				match++;
		// 				matnrkey = that.getView().getModel("F4ListModel").oData.F4List[i][key]; ////////////////////////////////
		// 				break;
		// 			}

		// 		}

		// 		//this._oValueHelpDialog.open();

		// 		var aSelectionSet = that._oValueHelpDialog.getFilterBar().getAllFilterItems();
		// 		that.implementSearch(sSearchQuery, aSelectionSet);
		// 		if (match > 0 && this.change) {
		// 			that._setSelectedMaterialAndUpdateInput(matnrkey);

		// 			that.objModel.oData[that.keyField1] = matnrkey;
		// 			that.objModel.updateBindings(true);
		// 			that.getView().getModel("ObjectPageModel").oData[that.keyField1] = matnrkey;
		// 			that.getView().getModel("ObjectPageModel").updateBindings(true);

		// 			sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
		// 				.None);

		// 			//that._oMultiInput.setValue(matnrkey);
		// 			if (key != "Zzprevpv") {
		// 				if (that.documentfieldsMandotoryCheck()) {
		// 					that.updateDocDescription();
		// 				}
		// 			}

		// 		} else if (count > 0)
		// 			that._oValueHelpDialog.open();
		// 		else {
		// 			sap.m.MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("no" + label1, [sSearchQuery]));
		// 			that.objModel.oData[that.keyField1] = "";
		// 			that.objModel.updateBindings(true);
		// 			that.getView().getModel("ObjectPageModel").oData[that.keyField1] = "";
		// 			that.getView().getModel("ObjectPageModel").updateBindings(true);
		// 			sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
		// 				.None);
		// 			//that._oMultiInput.setValue("");
		// 		}

		// 	}.bind(that),
		// 	error: function (oError) {}.bind(that)
		// });
	},
	implementSearch: function (sSearchQuery, aSelectionSet) {
		var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
			if (oControl.getControl().getValue()) {
				aResult.push(new sap.ui.model.Filter({
					path: oControl.getProperty("name"),
					operator: sap.ui.model.FilterOperator.Contains,
					value1: oControl.getControl().getValue()
				}));
			}

			return aResult;
		}, []);

		aFilters.push(new sap.ui.model.Filter({
			filters: [
				new sap.ui.model.Filter({
					path: this.keyField2,
					operator: sap.ui.model.FilterOperator.Contains,
					value1: sSearchQuery
				})
			],
			and: false
		}));

		this._filterTable(new sap.ui.model.Filter({
			filters: aFilters,
			and: true
		}));

	},
	_filterTable: function (oFilter) {
		var oValueHelpDialog = this._oValueHelpDialog;

		oValueHelpDialog.getTableAsync().then(function (oTable) {
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}

			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}

			oValueHelpDialog.update();
		});
	},
	onValueHelpOkPress: function (oEvent) {
		var aTokens = oEvent.getParameter("tokens");
		this._setSelectedMaterialAndUpdateInput(aTokens[0].getProperty("key"));
		this.objModel.oData[this.keyField1] = aTokens[0].getProperty("key");
		this.objModel.updateBindings(true);
		this.getView().getModel("ObjectPageModel").oData[this.keyField1] = aTokens[0].getProperty("key");
		this.getView().getModel("ObjectPageModel").updateBindings(true);
		sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
			.None);
		//this._oMultiInput.setValue(aTokens[0].getProperty("key"));
		this._oValueHelpDialog.close();
		if (this.keyField != "Zzprevpv") {
			if (this.documentfieldsMandotoryCheck()) {
				this.updateDocDescription();
			}

		}

	},
	onValueHelpCancelPress: function (oEvent) {
		this.objModel.oData[this.keyField1] = "";
		this.objModel.updateBindings(true);
		this.getView().getModel("ObjectPageModel").oData[this.keyField1] = "";
		this.getView().getModel("ObjectPageModel").updateBindings(true);
		sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
			.None);
		//this._oMultiInput.setValue("");
		this._oValueHelpDialog.close();
	},
	onFilterBarSearch: function (oEvent) {
		var sSearchQuery = this._oBasicSearchField.getValue(),
			aSelectionSet = this._oValueHelpDialog.getFilterBar().getAllFilterItems();
		//aSelectionSet = oEvent.getParameter("selectionSet");
		this.implementSearch(sSearchQuery, aSelectionSet);
	},
	_setSelectedMaterialAndUpdateInput: function (sKey) {
		this.DocF4ListModel.getData().F4List.some(function (f4entry) {
			this.objModel.oData[this.keyField1] = f4entry[this.keyField2];
			this.objModel.updateBindings(true);
			this.getView().getModel("ObjectPageModel").oData[this.keyField1] = f4entry[this.keyField2];
			this.getView().getModel("ObjectPageModel").updateBindings(true);
			sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData[this.valuststeId]).setValueState(sap.ui.core.ValueState
				.None);
			//this._oMultiInput.setValue(f4entry[this.keyField]);
			return f4entry[this.keyField2] === sKey &&
				this.DocF4ListModel.setProperty("/selectedF4Entry", f4entry);
		}, this);
	},
	documentfieldsMandotoryCheck: function () {
		var oView = this.getView();
		var docNo = oView.byId("idDocNo").getValue();
		var docType = oView.byId("idDocType").getValue();
		var docPart = oView.byId("idDocPart").getValue();
		var docVersion = oView.byId("idDocVersion").getValue();
		if (docNo != "" && docType != "" && docPart != "" && docVersion != "")
			return true;
		else
			return false;

	},
	documentAllfieldsMandotoryCheck: function () {
		var oView = this.getView();
		if (this.documentfieldsMandotoryCheck()) {
			var docDesigntion = oView.byId("idDocDesigntion").getValue();
			if (docDesigntion !== "") {
				return true;
			} else {
				return false;
			}

		} else
			return false;
	},
	updateDocDescription: function () {
		var oView = this.getView();
		var docNo = oView.byId("idDocNo").getValue();
		var docType = oView.byId("idDocType").getValue();
		var docPart = oView.byId("idDocPart").getValue();
		var docVersion = oView.byId("idDocVersion").getValue();
		var sViewId = "sed.mpe.prodver.manages1::sap.suite.ui.generic.template.ObjectPage.view.Details::C_ProdnVersObjPgTP";
		var sMaterial = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::MaterialForEdit::Field-input");
		var sPlant = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::PlantForEdit::Field-input");
		var sVersion = sap.ui.getCore().byId(sViewId +
			"--com.sap.vocabularies.UI.v1.FieldGroup::SelectionCriteria1::ProductionVersionForEdit::Field-input");
		var that = this;
		var customeModel = this.getOwnerComponent().getModel("Custom_Model");
		customeModel.read("/ZPP_DOCDESCSet(Dokar='" + docType + "',Doknr='" + docNo + "',Doktl='" + docPart + "',Dokvr='" + docVersion +
			"')", {
				success: function (oRetrievedResult) {
					if (oRetrievedResult.Dktxt != "") {
						that.objModel.oData["Dktxt"] = oRetrievedResult.Dktxt;
						that.objModel.updateBindings(true);
						that.getView().getModel("ObjectPageModel").oData["Dktxt"] = oRetrievedResult.Dktxt;
						that.getView().getModel("ObjectPageModel").updateBindings(true);
						sap.ui.getCore().byId(sap.ui.getCore().getModel(this.valuestateModel).oData["idDocDesigntion"]).setValueState(sap.ui.core.ValueState
							.None);
						//oView.byId("idDocDesigntion").setValue(oRetrievedResult.Dktxt);
					}
				}.bind(that),
				error: function (oError) {}.bind(that)
			});
	},
	onImpactPlanningChange: function (oEvent) {
		this.objModel.oData["Zzplanning"] = oEvent.getSource().getSelectedKey();
		this.objModel.updateBindings(true);
		this.getView().getModel("ObjectPageModel").oData["Zzplanning"] = oEvent.getSource().getSelectedKey();
		this.getView().getModel("ObjectPageModel").updateBindings(true);
		sap.ui.getCore().byId(sap.ui.getCore().getModel("idModel1").oData["idImpactPlanning"]).setValueState(sap.ui.core.ValueState.None);
	}

});