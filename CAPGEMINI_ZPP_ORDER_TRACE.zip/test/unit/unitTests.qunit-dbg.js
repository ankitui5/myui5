/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/safran/pp/zpp_order_trace/ordertrace/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});