/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/safran/dts/com.safran.pp.zpp_order_trace_ordertrace/ordertrace/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});
