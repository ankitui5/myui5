sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/safran/ewm/zewm_shippingsu/model/formatter"
], function (Controller, JSONModel, formatter) {
	"use strict";
	var oIMModel, oEWMModel;
	var _self, oTimeout;
	return Controller.extend("com.safran.ewm.zewm_shippingsu.controller.View1", {
		onInit: function () {
			oIMModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oIMModel, "oIMModel");
			oEWMModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oEWMModel, "oEWMModel");
		},
		onExit: function () {
			// Stop the interval on exit or navigation to different page. 
			clearInterval(oTimeout);
			oTimeout = null;
		},
		onSwitchChange: function (oEvent) {
			if (this.getView().byId("idSwitch").getState() == true) {
				_self = this;
				oTimeout = setInterval(function () {
					_self.getView().byId("smartTableID").rebindTable(true);
				}, 30000);
			} else if (this.getView().byId("idSwitch").getState() == false) {
				this.onExit();
			}
		},
		onDataReceived: function () {
			debugger;
			//this.getView().byId("smartFilterBar").getControlByKey("Plant").getTokens();
			//this.getView().byId("smartFilterBar").getControlByKey("Plant").getValue();
			var that = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZLEWM_SHIPPING_SUPERVISOR_APP_SRV/";
			var oReadModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
			oReadModel.setHeaders({
				"Content-Type": "application/json"
			});

			var fncSuccess = function (oData, oResponse) {
				debugger;
				that.getView().getModel("oIMModel").setData(oData.results);
			};

			var fncError = function (oError) { // error callback
			};

			var path = "IMDeliverySet?$filter=Plant eq '0311' or Plant eq '941H'";

			oReadModel.read(path, {
				success: fncSuccess,
				error: fncError
			});
		}
	});
});