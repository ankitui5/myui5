sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.safran.ewm.zewm_shippingsu.controller.View2", {
		onInit: function () {

		}
	});
});